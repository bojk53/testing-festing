public class lol{

	public static void main(String[] args) {
		lol();

	}
	public static void lol(){
		System.out.println("hahahaha!");
	}
}